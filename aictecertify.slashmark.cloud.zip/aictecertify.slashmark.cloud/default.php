<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intern Verification Portal</title>
    <meta name="title" content=" Intern verification portal ">

    <meta name="description" content="Discover the companies and organizations collaborating with SlashMark. Explore our partnerships.">

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<style>
        /* Your CSS styles go here */

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.verification-box {
    background-color: #fff;
    border: 1px solid #ccc;
    padding: 20px;
    max-width: 400px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: 20px; /* Add some margin for better spacing */
}

label {
    display: block;
    margin-bottom: 8px;
}

input {
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    box-sizing: border-box;
}

button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    background-color: #45a049;
}

.intern-details {
    margin-top: 20px;
}

.success-image {
    margin-top: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.success-image img {
    width: 20%; /* Set the width of the image to 20% */
    height: auto; /* Maintain the aspect ratio */
}

/* Media Queries for responsiveness */

@media only screen and (max-width: 600px) {
    .verification-box {
        max-width: 100%;
    }
}

    </style>
<body>
<script>alert("Verification successful!");</script>
<!-- ... Your existing HTML code ... -->
<div class="container">

<header>

    <a href="https://slashmark.cloud/" class="logo">Slash&nbsp;<span>Mark</span>&nbsp;IT<span>&nbsp;Solutions</span></a>


    
</header>
            <img src="images/Your paragraph text (6).png" alt="Verification Success Image" style="width: 100%; height: 50%">

           <div style="text-align: center;">
 <h1>Internship Completion Certificate<br> Successfully Verified!</h1>
                <h1 class="small-text">         <img src="images/checked.gif" alt="Verification Success Image" style="width: 10%; height: 10%">

    </div>
<!-- review section  -->

    <div class="verification-box">
                    <div class="intern-details text-center">
                <h3>Intern Details</h3>
                <p><strong>Name:</strong> Madineni Lokeshwar</p>
                <p><strong>InternID:</strong> SMI78250</p>
                <p><strong>Domain:</strong> Embedded Systems Internship</p>
                <p><strong>Batch:</strong> January 01, 2025 to May 01, 2025</p>
                <p><strong>No. Of Credits:</strong> 3</p>
                <p><strong>Internship Status:</strong> Completed</p>      
                </div>
                
            </div>


</body>
</html>

<!-- footer section  -->

<section class="footer">

    

    <div class="credit"><span> ©️ 2023 Slash Mark</span> | All rights reserved </div>

</section>

</div>















<!-- custom js file link -->
<script src="js/script.js"></script>


<script type="application/ld+json">
{
    "@context": "http://schema.org",
    "@type": "WebPage",
    "url": "https://slashmark.cloud/Companies.html",
    "name": "Partnership Companies at SlashMark",
    "description": "Explore our partner companies and collaborations.",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://slashmark.cloud/Companies.html",
        "query-input": "required name=search_term"
    }
}
</script>


</body>
</html>